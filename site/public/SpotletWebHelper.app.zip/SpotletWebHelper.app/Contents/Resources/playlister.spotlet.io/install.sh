#!/bin/bash

gem install bundler

bundle install --gemfile="${PWD}/playlister.spotlet.io/Gemfile"

BUNDLE_GEMFILE="${PWD}/playlister.spotlet.io/Gemfile" bundle exec ruby "${PWD}/playlister.spotlet.io/playlocal/app.rb"
